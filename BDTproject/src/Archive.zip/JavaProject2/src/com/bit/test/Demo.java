package com.bit.test;

public class Demo {
	//i want to add 5 and 8
	void add()
	{
		System.out.println(5+8);
	}

	//i want to add any two number
		void add(int x,int y)
		{
			System.out.println(x+y);
		}
		
		//print shaid
		void printValue() {
			System.out.println("shaid");
		}
		
		//print any name
			void printValue(String x) {
				System.out.println(x);
				System.out.println(x.length());
			}
			
			//print character 'c'
			void printcharValue() {
				System.out.println('c');
			}
			
			//print any character 
			void printcharValue(char ch) {
				System.out.println(ch);
			}
			
			//print true
			void printboolean()
			{
				System.out.println(true);
			}
			
			//print any boolean
			void printboolean(boolean result)
			{
				System.out.println(result);
			}
			
			void myclassValue(Demo d)
			{
				d.add();
				
			}
			

			void myclassValue(Fatima d)
			{
				
				
			}
			
			void myclassValue(Riffy r)
			{
				
				
			}
			
			
			
			
			
			
			
}
