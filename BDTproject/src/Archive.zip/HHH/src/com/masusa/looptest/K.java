package com.masusa.looptest;

public class K {
	

}
