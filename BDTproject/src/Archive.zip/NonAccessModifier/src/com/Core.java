package com;

import org.junit.Test;

public class Core {
	
	@Test
	public void loigin() {
		//Demo.b;
		A d=new A();
		Demo d1=new A();
		//d.a;
		//d.b;
		//d.m1();
		//d.m2();
		Demo s=new A();
		s.m2();
	}

}
