package com;

public class A extends Demo{
	//A x=m5();
	
	A m5() {
		return new A();
	}
	A(int a)
	{
		super(5);
		
		
	}
	A(){
		super(5);
		//this(5);
	}
	
	public static void m2() {
		//a++;
		
		//System.out.println(a);
		System.out.println(56);
	}

	@Override
	public void m3() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void m6() {
		// TODO Auto-generated method stub
		
	}

}
