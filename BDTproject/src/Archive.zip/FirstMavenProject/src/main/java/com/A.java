package com;

public class A {
	public void m1() {
		System.out.println("hi");
	}

}
