
public class DataClass {

}
