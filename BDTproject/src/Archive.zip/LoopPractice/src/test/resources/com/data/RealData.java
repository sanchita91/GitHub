package com.data;

public class RealData {
public static String title="Facebook";
}
