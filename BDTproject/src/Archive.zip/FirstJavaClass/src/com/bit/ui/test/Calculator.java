package com.bit.ui.test;

public class Calculator {
	
	static int v;//global or instance variable
	public static void main(String[] args) {
		Demo d=new Demo();//instantiate of a class or creating object of a class
		d.add();
		d.sub();
		d.mutiple();
		int f=d.a;
		
		
		
		
		
		int x=8;//local varial
		
		
		
		
		
		
		System.out.println(v);
		int a=6;
		int b=7;
		int c=a+b;
		//System.out.println(a+b);
		//System.out.println(a+b);
		
		System.out.println("Hello world");
	}

}
