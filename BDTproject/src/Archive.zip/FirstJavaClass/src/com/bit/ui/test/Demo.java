package com.bit.ui.test;

public class Demo {
	int x;
	int y;
	
	int a=12;
	 int b=7;
	 int c;
	 int s;
	 
	 void add1() {
		 x=6;
		 y=7;
		 int z=x+y;
	 }
	 
	void add() {
		x=8;
		y=9;
		int z=x+y;
		System.out.println(z);
		
		
		
		int r=9;
		c=a+b; 
		System.out.println(c);
	 }//end of method
	 void sub() {
		   s=c-a;
		 System.out.println(s);
	 }//end of sub method
	void mutiple() {
		int f=c*s;
	 System.out.println(c*s);
	}//end of multoply method

}
