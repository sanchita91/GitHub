package overrideExample;

public class MyRemoteWebdriver implements MyWebDriver{

	@Override
	public void get(String url) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void quit() {
		// TODO Auto-generated method stub
		
	}

}
