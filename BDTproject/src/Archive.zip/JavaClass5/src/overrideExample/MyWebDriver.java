package overrideExample;

public interface MyWebDriver {
	void get(String url);
	void quit();

}
