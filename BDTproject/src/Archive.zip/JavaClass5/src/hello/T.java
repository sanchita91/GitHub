package hello;

 class S{}
public class T {
//it has to be testing class
}
