package ModifierAndJunit;

public class SignUp {

	public void signUp(String fn,String ln,int ph,String em,String pass) {
		
	}
}
