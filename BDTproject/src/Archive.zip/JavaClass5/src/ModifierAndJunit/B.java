package ModifierAndJunit;

public class B {
	void m1() {}
	public void m2() {}
	protected void m3() {}
	private void m4() {}

}
