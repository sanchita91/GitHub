import org.openqa.selenium.By;

public class ObjectRepo {
	public static By ele=By.xpath("logo xpath");
	

}
