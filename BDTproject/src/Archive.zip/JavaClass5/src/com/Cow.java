package com;

public class Cow extends Animal{

	public  void eat() {
		System.out.println("grass");
	}
}
