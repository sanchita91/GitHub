package com;

public class TestingClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Cow c=new Cow();
		
		c.eat();
		
		

	}

}
