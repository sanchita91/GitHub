package com;

public class Animal {
	public void eat() {
		System.out.println("food");
	}

}
