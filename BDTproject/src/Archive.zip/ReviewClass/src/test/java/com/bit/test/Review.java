//package com.bit.test;
//
//import java.util.List;
//
//import org.junit.Test;
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Actions;
//
//public class Review {
//
//	static int a=7;//class variable
//	//Review r=new Review();
//	String s;//global or instance varaible
//	char c;
//	@Test
//	public void m1() {
//		int b;//local variable by default no value
//		System.out.println(c);
//		//static int c;
//		//amy(78);
//		A r=new A(3,"");
//		r.m1();
//		A r1=new A("yellow");
//		r1.m1();
//		r.m1();
//	}
//	//print 7
//	//click on login
//	WebDriver dr;
//	public void met() {
//		System.out.println(7);
//		dr.findElement(By.id("")).click();
//	}
//	
//	//print any numeric number
//	//click on any webElement
//	public void amy(int x,WebElement e) {
//		System.out.println(x);
//		e.click();
//	}
//	
//	//perform any action using any numeric number
//	//perform any action on any webelement
//	public WebElement md(int x,WebElement e) {
//		return e;
//	}
//	
//	public void test2(By x,String c) {
//		dr.findElement(x).sendKeys(c);
//	}
//	
//	public void click(WebElement e) {
//		e.click();
//	}
//	public void click(List<WebElement> eles,int index) {
//		Actions a;
//		
//	}
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//	
//}
